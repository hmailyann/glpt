#!/bin/bash 
#jdk环境变量
export JAVA_HOME=/usr/local/jdk
export CLASSPATH=$CLASSPATH:$JAVA_HOME/lib:$JAVA_HOME/jre/lib
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH:$HOMR/bin
JAR_NAME="maintenance-system-0.0.1-SNAPSHOT-exec.jar"
HTML="public"
DES_DIR="/home/website"
SOURCE_DIR="/root"
BAK_DIR="/export/backup/`date +%Y%m%d-%H%M`"
#检查程序是否在运行
is_exist(){
pid=`ps aux|grep $JAR_NAME|grep -v grep|awk '{print $2}' `
#如果不存在返回1,存在返回0 
if [ -z "${pid}" ]; then
return 1
else
return 0
fi
}
is_exist
if [ $? -eq "0" ]; then
kill -9 $pid
else
echo "${JAR_NAME} is not running" 
fi
cd $DES_DIR
mkdir -p $BAK_DIR;\mv  $JAR_NAME $HTML $BAK_DIR/
echo "备份成功"
cp $SOURCE_DIR/$JAR_NAME .
cp -r $SOURCE_DIR/$HTML .
is_exist
if [ $? -eq "0" ]; then
echo "${JAR_NAME} is already running. pid=${pid} ." 
else
nohup java -jar /home/website/$JAR_NAME --logging.config=./logback.xml  > $DES_DIR/logs/1.log 2>&1 &
echo "程序已启动..."
fi
is_exist
if [ $? -eq "0" ]; then
echo "${JAR_NAME} is running. pid is ${pid} "
else
echo "${JAR_NAME} is not running."
fi
exit
