#!/bin/sh  
cd /opt/website

/usr/local/jdk/bin/java -jar ./maintenance-system-0.0.1-SNAPSHOT-exec.jar --logging.config=./logback.xml  > /dev/null 2>&1 & 
echo $! > /var/run/domain.pid
