#!/bin/bash 
#PID=$(cat /var/run/domain.pid)  
#/usr/bin/kill -9 $PID
/usr/bin/kill -9 `ps aux|grep maintenance-system-0.0.1-SNAPSHOT-exec.jar|grep -v grep|awk '{print $2}'`
