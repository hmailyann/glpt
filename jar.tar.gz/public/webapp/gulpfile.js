var gulp = require('gulp'),
    less = require('gulp-less'),
    minifyCSS = require('gulp-minify-css'),
    uglify = require('gulp-uglify'),
    rename = require("gulp-rename");


gulp.task('default', function() {
    gulp.watch("src/less/*.less",function(p) {
        console.info(p);
        var cssPath = "css",
            lessPath = "src/less/*.less";
        try{
            gulp.src(lessPath)
                .pipe(less())
                .pipe(minifyCSS())
                .pipe(gulp.dest(cssPath));
        }catch (e){
            console.info(e)
        }

    });
    gulp.watch("src/js/*.js",function(p){
        console.info(p);
        var jsPath="js",
            srcPath="src/js/*.js";
        try {
            gulp.src(srcPath)
                .pipe(uglify())
                .pipe(gulp.dest(jsPath));
        }catch (e){
            console.info(e)
        }
    })
});