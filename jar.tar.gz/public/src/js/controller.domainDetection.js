(function() {
    app.controller('detectionDetail',['$scope','http', function (s,http) {
        s.domain=angular.copy(s.ngDialogData.domain);
        s.typeList=s.ngDialogData.typeList;
        s.domain.newType="";
        if(s.domain.name){
            s.domain.scanTime = s.domain.scanTime.toString() || 0;
            if(['0','60','120','180'].indexOf(s.domain.scanTime)<0){
                s.domain.scanTime='';
            };
            s.domain.hijackCheackType=''+s.domain.hijackCheackType
        }else{
            s.domain.type="";
            s.domain.hijackCheackType="1";
        }
        s.check=function () {
            if(!s.domain.name){
                s.error=true;
                s.errorMsg="请输入域名";
                return false
            }
            if(!s.domain.type){
                s.error=true;
                s.errorMsg="请输入类别";
                return false
            }
            if(!s.domain.scanTime){
                s.error=true;
                s.errorMsg="请选择检测间隔";
                return false
            }
            if(!s.domain.platform){
                s.error=true;
                s.errorMsg="请输入平台";
                return false
            }
            return true;
        };
        s.sub=function () {
            if(s.check()){
                http.post("saveDomain.do",s.domain,function (res) {
                    if(res.status==100000){
                        s.closeThisDialog(res);
                    }else if(res.status==100050){
                        s.error=true;
                        s.errorMsg="域名已存在";
                    }
                    else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }
        }
    }]);

    app.controller('domainDetection', ['$scope','$rootScope','$stateParams', 'Table','ngDialog','http','Tip', function (s,rs,$stateParams,Table,ngDialog,http,tip) {
        s.checkValue=[];
        s.table =Table.init({link: "queryDomain.do",query:{orderBy:"update_time",order:"desc"}});
        s.table.getList();
        s.typeList=[];
        s.getTypeList=function () {
            http.post("queryTypes.do",{},function (res) {
                if(res.status==100000){
                    s.typeList=res.message;
                }
            });
        };
        s.getTypeList();

        s.orderBy=function (name) {
            if(s.table.query.orderBy==name){
                s.table.query.order=(s.table.query.order=='desc'?'asc':'desc')
            }else{
                s.table.query.orderBy=name;
                s.table.query.order='desc';
            }
            s.table.getList(1);
        };
        s.xlsOption={
            startRow:2,
            col:["A","B","C","D","E"],
            colName:["name","type","platform","scanTime","hijackCheackType"]
        };
        s.$on("xlsxReady",function (event,data) {
            http.post("loadDomain.do",{param:data},function (res) {
                if(res.status==100000){
                    s.$broadcast("clearXlsx");
                    tip.success("成功上传"+res.message.SUCCESS+'条，失败'+res.message.FALSE+'条');
                    s.table.getList(1);
                }else if(res.status==100050){
                    tip.error("文件格式错误");
                }else{
                    tip.error(res.message);
                }
            })
        });
        s.$on("readError",function () {
            tip.error("请上传正确格式的文件，支持 xlsx 和 xls 格式");
        });

        s.detail=function (domain) {
            ngDialog.open({
                template:"template/detectionDialog.html",
                controller:"detectionDetail",
                closeByDocument :false,
                data:{domain:domain,typeList:s.typeList},
                className:"ngdialog-theme-default"
            }).closePromise.then(function(data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    s.getTypeList;
                    var msg = domain.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                }
            });
        };
        s.checkDomain=function (list) {
            tip.success("已开始检测，请耐心等待，不要重复点击");
            http.post("cheakDomain.do",{id:list.id},function (res) {
                if(res.status==100000){
                    s.table.getList(1);
                    tip.success("操作成功");
                }else{
                    tip.success(res.message);
                }
            })
        };
        s.checkAllDomain=function () {
            http.post("cheakAllDomain.do",{},function (res) {
                if(res.status==100000){
                    s.table.getList(1);
                    tip.success("操作成功");
                }else{
                    tip.success(res.message);
                }
            })
        };

        s.export=function (from) {
            var $iframe = $('<iframe id="down-file-iframe" />');
            var $form = $('<form target="down-file-iframe" method="post" />');
            $form.attr("action", "exportDomain.do");
            for (var key in s.table.query) {
                $form.append('<input type="hidden" name="' + key + '" value="' + s.table.query[key] + '" />');
            }
            $form.append('<input type="hidden" name="from" value="' + from + '" />');
            $iframe.append($form);
            $(document.body).append($iframe);
            $form[0].submit();
            $iframe.remove();
        };

        s.clearTask=function(){
            ngDialog.open({
                template:
                '<div class="confirm-dialog"> \
                <h2>您确定清除全部检测任务吗？</h2>\
                <div align="center">\
                    <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                    <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                </div></div>',
                plain: true
            })
                .closePromise.then(function(data) {
                if (data.value && data.value == "CONFIRM") {
                    http.post("clearTask.do", {}, function(res) {
                        if (res.status == 100000) {
                            tip.success("执行成功！");
                        }
                    });
                }
            });
        }

        s.delete= function(domain){
            if(domain || s.checkValue.length>0){
                var msg="",postData={};
                if(domain){
                    msg='您确定要删除域名“'+domain.name+'”吗？';
                    postData.ids=domain.id;
                }else{
                    msg='您确定要删除这些域名吗？';
                    postData.ids=s.checkValue.join(",");
                }
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>'+msg+'</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                    .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("deleteDomain.do", postData, function(res) {
                            if (res.status == 100000) {
                                s.table.getList(1);
                                tip.success("删除成功！");
                            }
                        });
                    }
                });
            }

        }
    }]);
})();
