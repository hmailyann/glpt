Date.prototype.Format=function(fmt){var o={"M+":this.getMonth()+1,"d+":this.getDate(),"h+":this.getHours(),"m+":this.getMinutes(),"s+":this.getSeconds(),"q+":Math.floor((this.getMonth()+3)/3),"S":this.getMilliseconds()};if(/(y+)/.test(fmt))fmt=fmt.replace(RegExp.$1,(this.getFullYear()+"").substr(4-RegExp.$1.length));for(var k in o)if(new RegExp("("+k+")").test(fmt))fmt=fmt.replace(RegExp.$1,(RegExp.$1.length==1)?(o[k]):(("00"+o[k]).substr((""+o[k]).length)));return fmt};

var app=angular.module('app',['ngSanitize', 'ui.select','nav','user']).config(["$provide", "$compileProvider", "$controllerProvider", "$filterProvider",
    function ($provide, $compileProvider, $controllerProvider, $filterProvider) {
        app.controller = $controllerProvider.register;
        app.directive = $compileProvider.directive;
        app.filter = $filterProvider.register;
        app.factory = $provide.factory;
        app.service = $provide.service;
        app.constant = $provide.constant;
    }
]);

app.filter('timeStamp', function() {
    return function(time) {
        var timeStamp=time+"秒";
        if( parseInt(time)> 60){
            var second = parseInt(time) % 60;
            var min = parseInt(time / 60);
            timeStamp = min + "分" + second + "秒";
            if( min > 60 ){
                min = parseInt(time / 60) % 60;
                var hour = parseInt( parseInt(time / 60) /60 );
                timeStamp = hour + "小时" + min + "分" + second + "秒";
                if( hour > 24 ){
                    hour = parseInt( parseInt(time / 60) /60 ) % 24;
                    var day = parseInt( parseInt( parseInt(time / 60) /60 ) / 24 );
                    timeStamp = day + "天" + hour + "小时" + min + "分" + second + "秒";
                }
            }
        }
        return timeStamp;
    }
});

app.directive("checkAll",function(){
    return {
        restrict: "AE",
        link: function (scope, element, attrs, ctrl) {
            $(document).off("change","."+attrs.checkAll).on("change","."+attrs.checkAll,function () { 
                scope.$apply(function(){
                    scope[attrs.ngModel]=false;
                });
                if($(this).prop("checked")){
                    scope[attrs.checkValue].push($(this).val())
                }else{
                    var me=$(this);
                    scope[attrs.checkValue]=scope[attrs.checkValue].filter(function (id) {
                        return id!=me.val();
                    })
                }
            });
            element.on("change",function () {
                var checkBoxes=$("."+attrs.checkAll+":enabled");
                if($(this).prop("checked")){
                    checkBoxes.prop("checked",true);
                    scope[attrs.checkValue].length = 0;
                    checkBoxes.each(function(i,checkbox){
                        scope[attrs.checkValue].push($(checkbox).val());
                    })
                }else{
                    checkBoxes.prop("checked",false);
                    scope[attrs.checkValue].length = 0; 
                }
            })
        }
    }
});

app.factory('webSocket',function () {
    function WebSocket(){
        this.socket = new SockJS('webSocket');
        this.stompClient=Stomp.over(this.socket);
        this.subList=[];
    }
    WebSocket.prototype.sub=function (url,callback) {
        var client=this.stompClient;
        this.subList.push({url:url,callback:callback});
        if(client.connected){
            client.subscribe(url, function(respnose) {
                callback(JSON.parse(respnose.body));
            });
        }
    };
    WebSocket.prototype.connect=function () {
        var client=this.stompClient;
        var list=this.subList;
        client.connect({}, function() {
            list.forEach(function (n) {
                client.subscribe(n.url, function(respnose) {
                    n.callback(JSON.parse(respnose.body));
                });
            })
        });
    };
    WebSocket.prototype.send=function (url,data) {
        this.stompClient.send("url", {}, JSON.stringify(data));
    };
    WebSocket.prototype.disconnect=function () {
        this.stompClient.disconnect();
    };
    return new WebSocket();
});


app.factory('http', ['$http', function ($http) {
    function Http() {}
    Http.prototype.get=function (url,data, callback) {
        $http({
            url: url,
            params: data,
            method: 'GET'
        }).then(function (bk) {
            var res = bk.data;
            if(res.status==110002){
                location.href = "login.html";
            }
            callback(res);
        }).catch(function (err) {
            callback({
                status:err.status,
                message:"接口错误"
            })
        })
    };

    Http.prototype.post=function (url,data, callback) {
        $http({
            url: url,
            data: JSON.stringify(data),
            method: 'POST'
        }).then(function (bk) {
            var res = bk.data;
            if(res.status==110002){
                location.href = "login.html";
            }
            callback(res);
        }).catch(function (err) {
            callback({
                status:err.status,
                message:"接口错误"
            })
        })
    };
    return new Http();
}]);