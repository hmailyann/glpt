(function() {
    app.controller("checkList",['$scope','Table','ngDialog','http',function (s,Table,ngDialog,http) {
        s.list=s.ngDialogData;
        s.table =Table.init({link: "queryCheckRecord.do",query:{name:s.list.name,cheakName:s.list.cheakPointName,orderBy:"update_time",order:"desc",pageSize:'10'}});
        s.table.getList();
        s.timeLimit={
            start:new Date(new Date()-(30*24*60*60*1000)).Format('yyyy-MM-dd'),
            end:new Date().Format('yyyy-MM-dd')
        };
        s.changeRemark=function (list) {
            http.post("addRemark.do",{id:list.id,remark:list.tempRemark},function (res) {
                if(res.status==100000){
                    list.changeRemark=0;
                    list.remark=list.tempRemark;
                }
            })
        };
        s.orderBy=function (name) {
            if(s.table.query.orderBy==name){
                s.table.query.order=(s.table.query.order=='desc'?'asc':'desc')
            }else{
                s.table.query.orderBy=name;
                s.table.query.order='desc';
            }
            s.table.getList(1);
        };
        s.checkHijack=function (list) {
            ngDialog.open({
                template:"template/hijackDialog.html",
                controller:"checkHijack",
                closeByDocument :false,
                data:list
            });
        };
    }]);
    app.controller('detailsManager', ['$scope','$stateParams','Table','http','ngDialog','Tip',function (s,$stateParams, Table,http,ngDialog,tip) {

        http.post("queryAllDomain.do",{},function (res) {
            if(res.status==100000){
                s.domainList=res.message;
                if($stateParams && $stateParams.domain){
                    s.nowDomain=s.domainList.filter(function (n) {
                        return n.name==$stateParams.domain
                    })[0].id
                }else
                    s.nowDomain=s.domainList[0].id;
                s.getDetails(s.nowDomain)
            }else{
                tip.error(res.message)
            }
        });
        s.chartOption={
                title : {
                    text: '各省检测总时间',
                    subtext: '一省多点取最大总时间',
                    x:'center'
                },
                tooltip : {
                    trigger: 'item'
                },
                dataRange: {
                    x: 'left',
                    y: 'bottom',
                    splitList: [
                        {start: 5.000,label:'差'},
                        {start: 3.000, end: 5.000,label:'较差'},
                        {start: 2.000, end: 3.000,label:'警告'},
                        {start: 1.000, end: 2.000,label:'较好'},
                        {end: 1.000,label:'好'}
                    ],
                    color: ['#E0022B', '#E09107', '#A3E00B']
                },
                series : [
                    {
                        name: '各省检测总时间',
                        type: 'map',
                        mapType: 'china',
                        roam: false,
                        itemStyle:{
                            normal:{
                                label:{
                                    show:true,
                                    textStyle: {
                                        color: "rgb(249, 249, 249)"
                                    }
                                }
                            },
                            emphasis:{label:{show:true}}
                        },
                        data:[]
                    }
                ]
        };
        s.query={
            orderBy:'cheak_point_name',
            order:'asc'
        };
        s.getDetails=function (id) {
            s.query.id=id;
            http.post("queryCheck.do",s.query,function (res) {
                if(res.status==100000){
                    s.details=res.message;
                    s.provinceData={};
                    for(var i=0;i<s.details.length;i++){
                        if(!s.provinceData[s.details[i].province] || s.provinceData[s.details[i].province]< parseFloat(s.details[i].totalTime)){
                            s.provinceData[s.details[i].province]=parseFloat(s.details[i].totalTime);
                        }
                    }
                    s.chartOption.series[0].data=[];
                    for(var p in s.provinceData){
                        s.chartOption.series[0].data.push({name: p,value: s.provinceData[p]});
                    }
                }else{
                    tip.error(res.message)
                }
            })
        };
        s.orderBy=function (name) {
            if(s.query.orderBy==name){
                s.query.order=(s.query.order=='desc'?'asc':'desc')
            }else{
                s.query.orderBy=name;
                s.query.order='desc';
            }
            s.getDetails(s.nowDomain);
        };
        s.changeDomain=function (id) {
            s.nowDomain=id;
            s.getDetails(id);
        };
        s.checkHijack=function (list) {
            ngDialog.open({
                template:"template/hijackDialog.html",
                controller:"checkHijack",
                closeByDocument :false,
                data:list
            });
        };
        s.checkList=function (list) {
            ngDialog.open({
                template:"template/checkListDialog.html",
                controller:"checkList",
                closeByDocument :false,
                data:list,
                className:"ngdialog-theme-default max"
            })
        }
    }]);
})();
