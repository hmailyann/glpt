var user=angular.module('user',['ngDialog']).directive("user",["$rootScope","$http","$state","ngDialog",function(rs,$http,$state,ngDialog){
    return {
        restrict: "AE",
        template :'<div class="user">\
                    <i class="icon-user"></i>\
                    <a ui-sref="account" class="username"></a>\
                    <a href="#" ng-click="logout()">退出登录</a>\
                </div>',
        link:function(scope, element, attrs, ctrl){
            scope.logout=function () {
                $http({url:"cancelUser.do",method:'POST'}).then(function () {
                    store.clear();
                    location.href="login.html";
                });
            };
            rs.finish=-2;
            if(!store.has("userInfo")) {
                $http({url: "getLoginUser.do", method: 'POST', cache: false}).then(function (bk) {
                    var res = bk.data;
                    if (res.status == 100000) {
                        rs.finish++;
                        rs.userInfo = res.message;
                        store.set("userInfo",res.message);
                        $(element).find(".username").html(rs.userInfo.username);
                        if (!rs.userInfo.lastestLoginTime) {
                            $state.go("account");
                        }
                    } else {
                        location.href = "login.html";
                    }
                });
            }else{
                rs.finish++;
                rs.userInfo = store.get("userInfo");
                $(element).find(".username").html(rs.userInfo.username);
            }
            if(!store.has("menuInfo")){
                $http({url:"getAllMenu.do",method:'POST'}).then(function (bk) {
                    var res=bk.data;
                    if(res.status==100000){
                        rs.finish++;
                        rs.menuInfo=res.message;
                        store.set("menuInfo",res.message);
                        rs.menuTree=[];
                    }else{
                        location.href="login.html";
                    }
                });
            }else{
                rs.finish++;
                rs.menuInfo=store.get("menuInfo");
                rs.menuTree=[];
            }
            if(!store.has("roleInfo")){
                $http({url:"getAllRoles.do",method:'POST'}).then(function (bk) {
                    debugger
                    var res=bk.data;
                    if(res.status==100000){
                        rs.finish++;
                        rs.roleInfo=res.message;
                        store.set("roleInfo",res.message);
                        rs.roleList={};
                        debugger
                        for(var i=0;i<rs.roleInfo.length;i++){
                            rs.roleList[rs.roleInfo[i].id]=rs.roleInfo[i].name;
                        }
                        debugger
                    }else{
                        location.href="login.html";
                    }
                });
            }else{
                rs.finish++;
                rs.roleInfo=store.get("roleInfo");
                rs.roleList={};
                for(var i=0;i<rs.roleInfo.length;i++){
                    rs.roleList[rs.roleInfo[i].id]=rs.roleInfo[i].name;
                }
            }


            rs.$watch('finish',function (n){
                if(n>0){
                    rs.userInfo.actIds=[];
                    rs.userInfo.secondMenu=[];
                    rs.userInfo.firstMenu=[];
                    for(var i=0;i<rs.userInfo.roleIds.length;i++){
                        for(var j=0;j<rs.roleInfo.length;j++){
                            if(rs.roleInfo[j].id==rs.userInfo.roleIds[i]){
                                rs.userInfo.actIds=rs.userInfo.actIds.concat(rs.roleInfo[j].menuIds);
                                break;
                            }
                        }
                    }
                    for(var k=0;k<rs.userInfo.actIds.length;k++){
                        for(var l=0;l<rs.menuInfo.length;l++){
                            if(rs.menuInfo[l].parentId && rs.menuInfo[l].id==rs.userInfo.actIds[k] && rs.userInfo.secondMenu.indexOf(rs.menuInfo[l].parentId)<0){
                                rs.userInfo.secondMenu.push(rs.menuInfo[l].parentId);
                            }
                        }
                    }
                    for(var m=0;m<rs.userInfo.secondMenu.length;m++){
                        for(var o=0;o<rs.menuInfo.length;o++){
                            if(rs.menuInfo[o].parentId && rs.menuInfo[o].id==rs.userInfo.secondMenu[m] && rs.userInfo.firstMenu.indexOf(rs.menuInfo[o].parentId)<0){
                                rs.userInfo.firstMenu.push(rs.menuInfo[o].parentId);
                            }
                        }
                    }
                    for(var p=0;p<rs.menuInfo.length;p++){
                        if(!rs.menuInfo[p].parentId && rs.userInfo.firstMenu.indexOf(rs.menuInfo[p].id)>-1){
                            var first=angular.copy(rs.menuInfo[p]);
                            first.child=[];
                            rs.menuTree.push(first)
                        }
                    }
                    for(var q=0;q<rs.menuInfo.length;q++){
                        if(rs.menuInfo[q].parentId){
                            for(var r=0;r<rs.menuTree.length;r++){
                                if(rs.menuInfo[q].parentId==rs.menuTree[r].id && rs.userInfo.secondMenu.indexOf(rs.menuInfo[q].id)>-1){
                                    rs.menuTree[r].child.push(rs.menuInfo[q]);
                                }
                            }
                        }
                    }
                }
            })
        }
    }
}]);
