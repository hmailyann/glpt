(function() {
    app.controller('operatingRecord', ['$scope', 'Table','ngDialog','http','Tip', function (s,Table,ngDialog,http,tip) {
        s.table =Table.init({link: "queryOperatingRecord.do"});
        s.table.getList(1)
    }]);
})();