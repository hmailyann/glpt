(function() {
    app.controller('addUser',['$scope', 'http','$rootScope', function (s, http,rs) {
        s.user={
            roleIds:[]
        };
        for(siteId in rs.userInfo.siteMap){
            if(siteId){
                s.user.siteId=siteId;
                break
            }
        }
        s.roleInfo=angular.copy(rs.validRoles);
        if(s.ngDialogData){
            s.user.id=s.ngDialogData.id;
            s.user.name=s.ngDialogData.name;
            s.user.username=s.ngDialogData.username;
            s.user.email=s.ngDialogData.email;
            s.user.roleIds=s.ngDialogData.roleIds;
            s.user.tel=s.ngDialogData.tel;
            s.user.siteId=s.ngDialogData.siteId ||s.user.siteId;
            for(var i=0;i<s.roleInfo.length;i++){
                if(s.user.roleIds.indexOf(s.roleInfo[i].id)>-1){
                    s.roleInfo[i].checked=true;
                }
            }
        }
        s.check=function(){
            if(!s.user.username){
                s.error=true;
                s.errorMsg="请填写用户名！";
                return false;
            }
            if(s.user.username && !/^[a-zA-Z0-9]+$/.test(s.user.username)){
                s.error=true;
                s.errorMsg="用户名仅能使用数字与字母组成！";
                return false;
            }
            if(s.user.name && !/^[a-zA-Z0-9\u4e00-\u9fa5]+$/.test(s.user.name)){
                s.error=true;
                s.errorMsg="姓名仅能使用汉字、数字与字母组成！";
                return false;
            }
            if(s.user.email && !/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(s.user.email)){
                s.error=true;
                s.errorMsg="请填写正确的邮箱！";
                return false;
            }
            if(s.user.tel && !/(^([0-9]{7,16})$)|(^([0-9]*)+(\+[0-9]{7,16})$)/.test(s.user.tel)){
                s.error=true;
                s.errorMsg="请填写正确的电话！";
                return false;
            }

            s.user.roleIds=[];
            for(var i=0;i<s.roleInfo.length;i++){
                if(s.roleInfo[i].checked){
                    s.user.roleIds.push(s.roleInfo[i].id);
                }
            }
            if(s.user.roleIds.length==0){
                s.error=true;
                s.errorMsg="请勾选角色！";
                return false;
            }
            return true
        };
        s.sub=function () {
            if(!s.loading && s.check()){
                s.loading=true;
                if(!s.user.id) s.user.password="670b14728ad9902aecba32e22fa4f6bd";
                http.post("saveUser.do",s.user,function (res) {
                    s.loading=false;
                    if(res.status==100000){
                        s.closeThisDialog(res)
                    }else if(res.status==100050){
                        s.error=true;
                        s.errorMsg="用户名已存在，请重新输入";
                    }else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }

        }
    }]);

    app.controller('bindPhone',['$scope','http',function (s, http) {
        s.user=s.ngDialogData;
        s.bind={
            mobile:"",
            username:s.user.username
        };
        http.post("queryTwilioMobile.do",{},function (res) {
            if(res.status=100000){
                s.phoneList=res.message;
                s.bind.mobile=s.phoneList[0];
            }else{

            }
        });
        s.sub=function () {
            if(!s.loading){
                s.loading=true;
                http.post("allocateTwilioMobile.do",s.bind,function (res) {
                    s.loading=false;
                    if(res.status=100000){
                        s.user.mobile=s.bind.mobile;
                        s.closeThisDialog(res);
                    }else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }

        }
    }]);

    app.controller('userManager', ['$scope', '$rootScope','Table','ngDialog','http','Tip', function (s, rs, Table,ngDialog,http,tip) {
        s.table =Table.init({link: "queryUsers.do"});
        s.table.getList();
        http.post("queryRoles.do",{pageSize:999,pageNo:1},function (res) {
           if(res.status==100000) {
               rs.validRoles=res.message.data;
           }
        });
        s.delUser=function(user){
            ngDialog.open({
                template:'<div class="confirm-dialog"> \
            <h2>您确定要删除用户“'+user.username+'”吗？</h2>\
            <div align="center">\
                <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
            </div></div>',
                plain: true
            }).closePromise.then(function (data) {
                if (data.value && data.value=='CONFIRM') {
                    http.post("delUserByUserId.do",{userId:user.id},function (res) {
                        if(res.status==100000){
                            s.table.getList(1);
                            tip.success("删除成功！")
                        }
                    })
                }
            });
        };
        s.editUser=function (user) {
            ngDialog.open({
                template:"template/userDialog.html",
                controller:"addUser",
                data:user
            }).closePromise.then(function (data) {
                if (data.value && data.value.status==100000) {
                    s.table.getList(1);
                    tip.success("修改成功！")
                }
            });
        };
        s.addUser=function () {
            ngDialog.open({
                template:"template/userDialog.html",
                controller:"addUser"
            }).closePromise.then(function (data) {
                if (data.value && data.value.status==100000) {
                    s.table.getList(1);
                    tip.success("添加成功！")
                }
            });
        };
    }]);
})();
