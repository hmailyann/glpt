
app.directive("chart",function(){
    return {
        restrict: "AE",
        link: function (scope, element, attrs, ctrl) {
            var myChart = echarts.init(element[0]);
            scope.$watch(attrs.chart,function (n) {
                if(n){
                    myChart.setOption(n);
                }
            },true);
        }
    }
});