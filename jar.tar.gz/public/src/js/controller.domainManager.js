(function() {
    app.controller('domainDetail',['$scope','http','$filter', function (s,http,$filter) {
        s.domain=angular.copy(s.ngDialogData);
        s.domain.newDomainEffect="";



        if(s.domain.isAdd){
            s.domain.status='2';
            s.domain.dnsDomains=[];
            s.domain.priceType="￥";
            s.domain.perPrice="";
            s.domain.perMonth="1月";
            s.api="saveBuyDomainUrl.do";
            s.domain.buyStartDate="";
            s.domain.buyEndDate="";
        }
        else if(!s.domain.id){
            console.log(s.domain)
            s.domain.status=''+s.domain.status;
            s.domain.buyStartDate=$filter("date")(s.domain.buyStartDate,"yyyy-MM-dd HH:mm:ss");
            s.domain.buyEndDate=$filter("date")(s.domain.buyEndDate,"yyyy-MM-dd HH:mm:ss");
            s.domain.priceType=s.domain.domainPrice.split("/")[0];
            s.domain.perPrice=s.domain.domainPrice.split("/")[1];
            s.domain.perMonth=s.domain.domainPrice.split("/")[2];
            s.api="saveBuyDomainUrl.do";
            for(var i=0;i<s.domain.dnsDomains.length;i++){
                s.domain.dnsDomains[i].analysisUrlList=[];
                if(s.domain.dnsDomains[i].analysisUrl){
                     for(var j=0;j<s.domain.dnsDomains[i].analysisUrl.split(",").length;j++){
                         s.domain.dnsDomains[i].analysisUrlList.push({url:s.domain.dnsDomains[i].analysisUrl.split(",")[j]})
                     }
                }
            }
        }
        else{
            s.domain.status=''+s.domain.status;
            s.domain.buyStartDate=$filter("date")(s.domain.buyStartDate,"yyyy-MM-dd HH:mm:ss");
            s.domain.buyEndDate=$filter("date")(s.domain.buyEndDate,"yyyy-MM-dd HH:mm:ss");
            s.domain.priceType=s.domain.domainPrice.split("/")[0];
            s.domain.perPrice=s.domain.domainPrice.split("/")[1];
            s.domain.perMonth=s.domain.domainPrice.split("/")[2];
            s.api="updateBuyDomainUrl.do";
            for(var i=0;i<s.domain.dnsDomains.length;i++){
                s.domain.dnsDomains[i].analysisUrlList=[];
                if(s.domain.dnsDomains[i].analysisUrl){
                     for(var j=0;j<s.domain.dnsDomains[i].analysisUrl.split(",").length;j++){
                         s.domain.dnsDomains[i].analysisUrlList.push({url:s.domain.dnsDomains[i].analysisUrl.split(",")[j]})
                     }
                }
            }
        }
        http.post("queryDomainEffect.do",{},function (res) {

            if(res.status=100000){
                s.domainEffectList=res.message;
                // console.log(s.certEffectList);
                if(s.domainEffectList.length>0&&!s.domain.domainEffect){
                    s.domain.domainEffect=s.domainEffectList[0];
                    s.domainEffectList.push({id:9999,name:'自定义'})

                }
                else if(s.domain.domainEffect&&s.domainEffectList.length>0){
                    for (var index = 0; index < s.domainEffectList.length; index++) {
                        if(s.domain.domainEffect==s.domainEffectList[index].name){
                            s.domain.domainEffect = s.domainEffectList[index];
                        }
                    }
                    s.domainEffectList.push({id:9999,name:'自定义'})

                }
                else if(!s.domain.id && s.domainEffectList.length==0){
                    s.domain.certEffect="";
                }
            }
        });
        s.delDns=function (n) {
            s.domain.dnsDomains.splice(n,1)
        };
        s.addDns=function () {
            s.domain.dnsDomains.push({});
        };
        s.delAnalysisUrl=function (x,n) {
            s.domain.dnsDomains[x].analysisUrlList.splice(n,1)
        };
        s.addAnalysisUrl=function (n) {
            s.domain.dnsDomains[n].analysisUrlList=s.domain.dnsDomains[n].analysisUrlList || [];
            s.domain.dnsDomains[n].analysisUrlList.push({url:""});
        };
        s.delDnsCnames=function (x,n) {
            s.domain.dnsDomains[x].dnsCnames.splice(n,1)
        };
        s.addDnsCnames=function (n) {
            s.domain.dnsDomains[n].dnsCnames=s.domain.dnsDomains[n].dnsCnames || [];
            s.domain.dnsDomains[n].dnsCnames.push({cname:"",ctype:"",cvalue:""});
        };
        s.check=function () {
            if(!s.domain.analysisDomain){
                s.error=true;
                s.errorMsg="请输入域名";
                return false
            }
            if(!s.domain.platform){
                s.error=true;
                s.errorMsg="请输入平台";
                return false
            }
            if(!s.domain.domainEffect && !s.domain.newDomainEffect){
                s.error=true;
                s.errorMsg="请输入域名作用";
                return false
            }
            if(!s.domain.buyDomainUrl){
                s.error=true;
                s.errorMsg="请输入域名商网址";
                return false
            }
            if(!s.domain.buyUsername){
                s.error=true;
                s.errorMsg="请输入域名注册用户名";
                return false
            }
            if(!s.domain.buyPassword){
                s.error=true;
                s.errorMsg="请输入域名注册密码";
                return false
            }
            if(!s.domain.buyMobile){
                s.error=true;
                s.errorMsg="请输入域名注册手机";
                return false
            }
            if(!s.domain.buyStartDate){
                s.error=true;
                s.errorMsg="请输入域名购买时间";
                return false
            }
            if(!s.domain.perPrice){
                s.error=true;
                s.errorMsg="请输入服务器价格";
                return false
            }
            for(var i=0;i<s.domain.dnsDomains.length;i++){
                if(!s.domain.dnsDomains[i].dnsDomainUrl){
                    s.error=true;
                    s.errorMsg="请输入第"+(i+1)+"个DNS的网址";
                    return false
                }
                if(!s.domain.dnsDomains[i].dnsUsername){
                    s.error=true;
                    s.errorMsg="请输入第"+(i+1)+"个DNS的用户名";
                    return false
                }
                if(!s.domain.dnsDomains[i].dnsPassword){
                    s.error=true;
                    s.errorMsg="请输入第"+(i+1)+"个DNS的密码";
                    return false
                }
                if(!s.domain.dnsDomains[i].dnsMobile){
                    s.error=true;
                    s.errorMsg="请输入第"+(i+1)+"个DNS的手机";
                    return false
                }
            }
            s.domain.domainPrice=s.domain.priceType+"/"+s.domain.perPrice+"/"+s.domain.perMonth;
            return true;
        };
        s.sub=function () {
            if(s.check()){
                var data=angular.copy(s.domain);
                // if(!s.domain.certEffect && s.domaina.newCertEffect){
                //     data.certEffect=s.domain.newCertEffect;
                // }
                // if(s.domain.certEffect && s.domain.newCertEffect){
                //     data.certEffect=s.domain.newCertEffect;
                // }
                // if(s.domain.certEffect.name!='自定义'){
                //     data.certEffect =s.domain.certEffect.name;
                // }
                if(!s.domain.domainEffect && s.domain.newDomainEffect){
                    data.domainEffect=s.domain.newCertEffect;
                }
                if(s.domain.domainEffect && s.domain.newDomainEffect){
                    data.domainEffect=s.domain.newDomainEffect;
                }
                if(s.domain.domainEffect.name!='自定义'){
                    data.domainEffect = s.domain.domainEffect.name;
                }
                for(var i=0;i<data.dnsDomains.length;i++){
                    if(data.dnsDomains[i].analysisUrlList && data.dnsDomains[i].analysisUrlList.length){
                        var analysisUrlArry=[];
                        data.dnsDomains[i].analysisUrlList.forEach(function (list) {
                            analysisUrlArry.push(list.url);
                        });
                        data.dnsDomains[i].analysisUrl=analysisUrlArry.join(",");
                    }
                    delete data.dnsDomains[i].analysisUrlList;
                    if(!data.dnsDomains[i].dnsCnames){
                        data.dnsDomains[i].dnsCnames=[];
                    }
                }
                // if(!s.domain.domainEffect && s.domain.newDomainEffect){
                //     data.domainEffect=s.domain.newDomainEffect;
                // }

                http.post(s.api,data,function (res) {
                    if(res.status==100000){
                        s.closeThisDialog(res);
                    }else if(res.status==100050){
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                    else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }

        }
    }]);

    app.controller('domainManager', ['$scope','$rootScope','$state', 'Table','ngDialog','http','Tip', function (s,rs,$state,Table,ngDialog,http,tip) {
        http.post("queryDomainEffect.do",{},function (res) {
            if(res.status=100000){
                s.domainEffectList=res.message;
            }
        });
        s.checkValue=[];
        s.now = + new Date();
        s.table =Table.init({link: "queryBuyDomainUrl.do"});
        s.table.getList();
        s.xlsOption={
            startRow:2,
            col:["A","B","C","D","E",
                "F","G","H","I","J",
                "K","L","M","N","O",
                "P","Q","R","S","T","U","V","W","X","Y"],
            colName:["analysisDomain","platform","status","domainEffect","buyDomainUrl","buyUsername",
                "buyPassword","buyMobile","buyEmail","buyEmailPassword","domainPrice",
                "domainPurchaser","buyStartDate","buyEndDate","dnsDomainUrl","dnsUsername","dnsPassword",
                "dnsMobile","dnsEmail","dnsEmailPassword","remark","analysisUrl","cname","ctype","cvalue"]
        };
        s.$on("xlsxReady",function (event,data) {
            var domains=[];
            for(var i=0;i<data.length;i++){
                if(data[i].analysisDomain){
                    domains.push({
                        analysisDomain:data[i].analysisDomain,
                        platform:data[i].platform,
                        status:data[i].status,
                        domainEffect:data[i].domainEffect,
                        buyDomainUrl:data[i].buyDomainUrl,
                        buyUsername:data[i].buyUsername,
                        buyPassword:data[i].buyPassword,
                        buyMobile:data[i].buyMobile,
                        buyEmail:data[i].buyEmail || '',
                        buyEmailPassword:data[i].buyEmailPassword || '',
                        domainPrice:data[i].domainPrice || '',
                        domainPurchaser:data[i].domainPurchaser || '',
                        buyStartDate:data[i].buyStartDate,
                        buyEndDate:data[i].buyEndDate,
                        dnsDomains:[]
                    });
                    if(data[i].dnsDomainUrl){
                        domains[domains.length-1].dnsDomains.push({
                            dnsDomainUrl:data[i].dnsDomainUrl,
                            dnsUsername:data[i].dnsUsername,
                            dnsPassword:data[i].dnsPassword,
                            dnsMobile:data[i].dnsMobile,
                            dnsEmail:data[i].dnsEmail || '',
                            dnsEmailPassword:data[i].dnsEmailPassword || '',
                            remark:data[i].remark || '',
                            analysisUrl:data[i].analysisUrl || '',
                            dnsCnames:[]
                        });
                        if(data[i].cname || data[i].ctype || data[i].cvalue){
                            domains[domains.length-1].dnsDomains[domains[domains.length-1].dnsDomains.length-1].dnsCnames.push({
                                cname:data[i].cname || '',
                                ctype:data[i].ctype || '',
                                cvalue:data[i].cvalue || ''
                            })
                        }
                    }
                }else{
                    if(data[i].dnsDomainUrl){
                        domains[domains.length-1].dnsDomains.push({
                            dnsDomainUrl:data[i].dnsDomainUrl,
                            dnsUsername:data[i].dnsUsername,
                            dnsPassword:data[i].dnsPassword,
                            dnsMobile:data[i].dnsMobile,
                            dnsEmail:data[i].dnsEmail || '',
                            dnsEmailPassword:data[i].dnsEmailPassword || '',
                            remark:data[i].remark || '',
                            analysisUrl:data[i].analysisUrl || '',
                            dnsCnames:[]
                        });
                        if(data[i].cname || data[i].ctype || data[i].cvalue){
                            domains[domains.length-1].dnsDomains[domains[domains.length-1].dnsDomains.length-1].dnsCnames.push({
                                cname:data[i].cname || '',
                                ctype:data[i].ctype || '',
                                cvalue:data[i].cvalue || ''
                            })
                        }
                    }else{
                        if(data[i].cname || data[i].ctype || data[i].cvalue){
                            domains[domains.length-1].dnsDomains[domains[domains.length-1].dnsDomains.length-1].dnsCnames.push({
                                cname:data[i].cname || '',
                                ctype:data[i].ctype || '',
                                cvalue:data[i].cvalue || ''
                            })
                        }
                    }
                }
            }
            http.post("loadDomainUrl.do",{param:domains},function (res) {
                if(res.status==100000){
                    s.$broadcast("clearXlsx");
                    tip.success("成功上传"+res.message.SUCCESS+'条，失败'+res.message.FALSE+'条');
                    s.table.getList(1);
                }else if(res.status==100050){
                    tip.error("文件格式错误");
                }else{
                    tip.error(res.message);
                }
            })
        });
        s.$on("readError",function () {
            tip.error("请上传正确格式的文件，支持 xlsx 和 xls 格式");
        });

        s.detail=function (domain,status) {
            status?domain.id = "" : "";
            ngDialog.open({
                template:"template/domainDialog.html",
                controller:"domainDetail",
                closeByDocument :false,
                data:domain,
                className:"ngdialog-theme-default large"
            }).closePromise.then(function(data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    var msg = domain.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                  }
              });
        };
        // s.extend=function (list) {
        //     ngDialog.open({
        //         template:
        //         '<div class="confirm-dialog"> \
        //         <h2>确定延长“'+list.analysisDomain+'”的过期时间吗？</h2>\
        //             <div align="center">\
        //                 <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
        //                 <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
        //             </div></div>',
        //         plain: true
        //     })
        //         .closePromise.then(function(data) {
        //         if (data.value && data.value == "CONFIRM") {
        //             http.post("extendDomainTime.do", {id:list.id}, function(res) {
        //                 if (res.status == 100000) {
        //                     s.table.getList(1);
        //                     tip.success("延期成功！");
        //                 }
        //             });
        //         }
        //     });
        // };

        s.export=function () {
            var $iframe = $('<iframe id="down-file-iframe" />');
            var $form = $('<form target="down-file-iframe" method="post" />');
            $form.attr("action", "exportDomainUrl.do");
            for (var key in s.table.query) {
                $form.append('<input type="hidden" name="' + key + '" value="' + s.table.query[key] + '" />');
            }
            $iframe.append($form);
            $(document.body).append($iframe);
            $form[0].submit();
            $iframe.remove();
        };
        s.change=function (domain,n) {
            var postData=function() {
                http.post("updateDomainStatus.do", {id: domain.id, status: n}, function (res) {
                    if (res.status == 100000) {
                        domain.status = n;
                        tip.success("操作成功！");
                    }
                })
            };
            if(n==4){
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>您确定要将域名'+domain.analysisDomain+'标记为废弃吗？</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                    .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        postData();
                    }
                });
            }else{
                postData();
            }
        };
        s.delete= function(domain){
            if(domain || s.checkValue.length>0){
                var msg="",postData={};
                if(domain){
                    msg='您确定要删除域名“'+domain.analysisDomain+'”吗？';
                    postData.ids=domain.id;
                }else{
                    msg='您确定要删除这些域名吗？';
                    postData.ids=s.checkValue.join(",");
                }
                
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>'+msg+'</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("deleteBuyDomainUrl.do", postData, function(res) {
                        if (res.status == 100000) {
                            s.table.getList(1);
                            tip.success("删除成功！");
                        }
                        });
                    }
                });
            }
        };
        s.checkDomain=function (list) {
            var postData={};
            if(list && list.id){
                postData.ids=list.id;
                http.post("loadCheakDomain.do", postData, function(res) {
                    if (res.status == 100000) {
                        tip.success("操作成功！");
                        $state.go("detailsManagerDetail",{domain:list.analysisDomain})
                    }
                });
            }
            else if(s.checkValue.length>0){
                postData.ids=s.checkValue.join(",");
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>确定将这些域名加入检测列表吗？</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                }).closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("loadCheakDomain.do", postData, function(res) {
                            if (res.status == 100000) {
                                tip.success("操作成功！");
                            }
                        });
                    }
                });
            }
        };
        s.search=function(){
            if(s.table.query.domainEffect){
                s.table.query.domainEffect = s.table.query.domainEffect.name
            }
            s.table.getList(1);
        }
    }]);
})();
