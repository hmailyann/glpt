(function() {
    app.controller('certificateDetail',['$scope','http','$filter', function (s,http,$filter) {
        s.domain=angular.copy(s.ngDialogData);
        s.domain.newCertEffect="";
        console.log()
        if(!s.domain.id){
            s.domain.status='2';
            s.domain.priceType="￥";
            s.domain.perPrice="";
            s.domain.perMonth="1月";
            s.api="saveCertificate.do";
            s.domain.buyStartDate="";
            s.domain.buyEndDate="";
        }
        else{
            s.domain.status=''+s.domain.status;
            s.domain.buyStartDate=$filter("date")(s.domain.buyStartDate,"yyyy-MM-dd HH:mm:ss");
            s.domain.buyEndDate=$filter("date")(s.domain.buyEndDate,"yyyy-MM-dd HH:mm:ss");
            s.domain.priceType=s.domain.certPrice.split("/")[0];
            s.domain.perPrice=s.domain.certPrice.split("/")[1];
            s.domain.perMonth=s.domain.certPrice.split("/")[2];
            s.api="updateCertificate.do";
        }
        http.post("queryCertEffect.do",{},function (res) {
            if(res.status=100000){
                s.certEffectList=res.message;
                console.log(s.certEffectList);
                if(s.certEffectList.length>0&&!s.domain.certEffect){
                    s.domain.certEffect=s.certEffectList[0];
                    s.certEffectList.push({id:9999,name:'自定义'})

                }
                else if(s.domain.certEffect&&s.certEffectList.length>0){
                    for (var index = 0; index < s.certEffectList.length; index++) {
                        if(s.domain.certEffect==s.certEffectList[index].name){
                            s.domain.certEffect = s.certEffectList[index];
                        }
                    }
                    s.certEffectList.push({id:9999,name:'自定义'})

                }
                else if(!s.domain.id && s.certEffectList.length==0){
                    s.domain.certEffect="";
                }
            }
        });
        s.delDns=function (n) {
            s.domain.dnsDomains.splice(n,1)
        };
        s.addDns=function () {
            s.domain.dnsDomains.push({});
        };
        s.delAnalysisUrl=function (x,n) {
            s.domain.dnsDomains[x].analysisUrlList.splice(n,1)
        };
        s.addAnalysisUrl=function (n) {
            s.domain.dnsDomains[n].analysisUrlList=s.domain.dnsDomains[n].analysisUrlList || [];
            s.domain.dnsDomains[n].analysisUrlList.push({url:""});
        };
        s.delDnsCnames=function (x,n) {
            s.domain.dnsDomains[x].dnsCnames.splice(n,1)
        };
        s.addDnsCnames=function (n) {
            s.domain.dnsDomains[n].dnsCnames=s.domain.dnsDomains[n].dnsCnames || [];
            s.domain.dnsDomains[n].dnsCnames.push({cname:"",ctype:"",cvalue:""});
        };
        s.check=function () {
            // if(!s.domain.name){
            //     s.error=true;
            //     s.errorMsg="请输入证书";
            //     return false
            // }
            if(!s.domain.platform){
                s.error=true;
                s.errorMsg="请输入平台";
                return false
            }
            if(!s.domain.certEffect && !s.domain.newCertEffect){
                s.error=true;
                s.errorMsg="请输入证书作用";
                return false
            }
            if(!s.domain.buyDomainUrl){
                s.error=true;
                s.errorMsg="请输入证书商网址";
                return false
            }
            if(!s.domain.buyUsername){
                s.error=true;
                s.errorMsg="请输入证书注册用户名";
                return false
            }
            if(!s.domain.buyPassword){
                s.error=true;
                s.errorMsg="请输入证书注册密码";
                return false
            }
            if(!s.domain.buyMobile){
                s.error=true;
                s.errorMsg="请输入证书注册手机";
                return false
            }
            if(!s.domain.buyStartDate){
                s.error=true;
                s.errorMsg="请输入证书购买时间";
                return false
            }

            s.domain.certPrice=s.domain.priceType+"/"+s.domain.perPrice+"/"+s.domain.perMonth;
            return true;
        };
        s.sub=function () {
            if(s.check()){
                console.log(s.domain.certEffect.name)
                
                var data=angular.copy(s.domain);
                console.log()
                if(!s.domain.certEffect && s.domaina.newCertEffect){
                    data.certEffect=s.domain.newCertEffect;
                }
                if(s.domain.certEffect && s.domain.newCertEffect){
                    data.certEffect=s.domain.newCertEffect;
                }
                if(s.domain.certEffect.name!='自定义'){
                    data.certEffect =s.domain.certEffect.name;
                }
                http.post(s.api,data,function (res) {
                    if(res.status==100000){
                        s.closeThisDialog(res);
                    }else if(res.status==100050){
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                    else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }

        }
    }]);
    app.controller('certificateManager', ['$scope','$rootScope','$state', 'Table','ngDialog','http','Tip', function (s,rs,$state,Table,ngDialog,http,tip) {
        http.post("queryCertEffect.do",{},function (res) {
            if(res.status=100000){
                s.certEffectList=res.message;
            }
        });
        s.checkValue=[];
        s.now = + new Date();
        s.table =Table.init({link: "queryCertificateByCondition.do"});
        s.table.getList();
        s.xlsOption={
            startRow:2,
            col:["A","B","C","D","E",
                "F","G","H","I","J",
                "K","L","M","N","O","P"],
            colName:["name","platform","bindDomain","status","certEffect","buyDomainUrl",
                "buyUsername","buyPassword","buyMobile","buyEmail","buyEmailPassword","certPrice",
                "certPurchaser","buyStartDate","buyEndDate","remark"]
        };
        s.$on("xlsxReady",function (event,data) {
            for (var index = 0; index < data.length; index++) {
                if(data[index].status=="待用"){
                    data[index].status = 2;
                }
                else if(data[index].status=="启用"){
                    data[index].status = 1;
                }
                else if(data[index].status=="停用"){
                    data[index].status = 3;
                }
                else if(data[index].status=="废弃"){
                    data[index].status = 4;
                }
            }
            http.post("loadCertificate.do",{param:data},function (res) {
                if(res.status==100000){
                    s.$broadcast("clearXlsx");
                    tip.success("成功上传"+res.message.SUCCESS+'条，失败'+res.message.FALSE+'条');
                    s.table.getList(1);
                }else if(res.status==100050){
                    tip.error("文件格式错误");
                }else{
                    tip.error(res.message);
                }
            })
        });
        s.$on("readError",function () {
            tip.error("请上传正确格式的文件，支持 xlsx 和 xls 格式");
        });

       
        s.detail=function (domain,status) {
            status?domain.id = "" : "";
            ngDialog.open({
                template:"template/certificateDailog.html",
                controller:"certificateDetail",
                closeByDocument :false,
                data:domain,
                className:"ngdialog-theme-default large"
            }).closePromise.then(function(data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    var msg = domain.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                  }
              });
        };
        s.export=function () {
            var $iframe = $('<iframe id="down-file-iframe" />');
            var $form = $('<form target="down-file-iframe" method="post" />');
            $form.attr("action", "exportCertificate.do");
            for (var key in s.table.query) {
                $form.append('<input type="hidden" name="' + key + '" value="' + s.table.query[key] + '" />');
            }
            $iframe.append($form);
            $(document.body).append($iframe);
            $form[0].submit();
            $iframe.remove();
        };
        s.change=function (domain,n) {
            var postData=function() {
                http.post("updateDomainStatus.do", {id: domain.id, status: n}, function (res) {
                    if (res.status == 100000) {
                        domain.status = n;
                        tip.success("操作成功！");
                    }
                })
            };
            if(n==4){
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>您确定要将证书'+domain.name+'标记为废弃吗？</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                    .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        postData();
                    }
                });
            }else{
                postData();
            }
        };
        s.delete= function(domain){
            if(domain || s.checkValue.length>0){
                var msg="",postData={};
                if(domain){
                    msg='您确定要删除证书“'+domain.name+'”吗？';
                    postData.ids= [];
                    postData.ids.push(domain.id);
                }else{
                    msg='您确定要删除这些证书吗？';
                    console.log(s.checkValue);
                    postData.ids = []
                    postData.ids=s.checkValue;
                }
                
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>'+msg+'</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("deleteCertificateByIds.do", postData, function(res) {
                        if (res.status == 100000) {
                            s.table.getList(1);
                            tip.success("删除成功！");
                        }
                        });
                    }
                });
            }
        };
        s.checkDomain=function (list) {
            var postData={};
            if(list && list.id){
                postData.ids=list.id;
                http.post("loadCheakDomain.do", postData, function(res) {
                    if (res.status == 100000) {
                        tip.success("操作成功！");
                        $state.go("detailsManagerDetail",{domain:list.name})
                    }
                });
            }
            else if(s.checkValue.length>0){
                postData.ids=s.checkValue.join(",");
                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>确定将这些证书加入检测列表吗？</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                }).closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("loadCheakDomain.do", postData, function(res) {
                            if (res.status == 100000) {
                                tip.success("操作成功！");
                            }
                        });
                    }
                });
            }
        }
    }]);
})();
