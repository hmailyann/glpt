var nav=angular.module('nav',['ui.router','oc.lazyLoad']);
var version=+new Date();
nav.constant('myModulesConfig', [
    {
        name: 'ngDialog',
        files: [
            "css/ngDialog.min.css",
            "css/ngDialog-theme-default.min.css",
            "css/dialog.css",
            "js/factory.tip.js"
        ]
    },{
        name:'datePicker',
        files:[
            "js/My97DatePicker/WdatePicker.js",
            "js/directive.datepicker.js"
        ]
    },{
        name: "imgUpload",
        files: ["js/directive.imgUpload.js"]
    },
    {
        name:'echarts',
        files:[
            "js/echarts.common.min.js",
            "js/directive.chart.js"
        ]
    },{
        name:'datatype',
        files:[
            "js/directive.datatype.js"
        ]
    },{
        name:'table',
        files:[
            "js/factory.table.js",
            "css/table.css?v="+version
        ]
    },{
        name:'xlsx',
        files:[
            "js/xlsx.core.min.js",
            "src/js/directive.xlsx.js"
        ]
    },{
        name:"welcome",
        files:[
            "css/welcome.css",
            "js/controller.welcome.js?v="+version
        ]
    },{
        name:"userManager",
        files:[
            "js/controller.userManager.js?v="+version,
            "css/userManager.css"
        ]
    },{
        name:"roleManager",
        files:[
            "js/controller.roleManager.js?v="+version,
            "css/roleManager.css"
        ]
    },{
        name:"account",
        files:[
            "js/controller.account.js?v="+version,
            "js/md5.min.js",
            "css/account.css"
        ]
    },{
        name:"domainDetection",
        files:[
            "src/js/controller.domainDetection.js",
            "css/domainDetection.css"
        ]
    },{
        name:"certificateManager",
        files:[
            "js/controller.certificateManager.js",
            "css/domainManager.css"
        ]
    },{
        name:"certificateBillManager",
        files:[
            "js/controller.certificateBillManager.js",
            "css/domainManager.css"
        ]
    },{
        name:"domainManager",
        files:[
            "js/controller.domainManager.js",
            "css/domainManager.css"
        ]
    },{
        name:"domainBillManager",
        files:[
            "js/controller.domainBillManager.js"
        ]
    },{
        name:"detailsManager",
        files:[
            "js/controller.detailsManager.js",
            "css/detailsManager.css"
        ]
    },{
        name:"serviceManager",
        files:[
            "js/controller.serviceManager.js",
            "css/domainManager.css"
        ]
    },{
        name:"serviceBillManager",
        files:[
            "js/controller.serviceBillManager.js"
        ]
    },{
        name:"cheakMonitoring",
        files:[
            "js/controller.cheakMonitoring.js"
        ]
    },{
        name:"operatingRecord",
        files:[
            "js/controller.operatingRecord.js"
        ]
    }
]);
nav.config(['$stateProvider','$urlRouterProvider','$ocLazyLoadProvider','myModulesConfig', function($stateProvider, $urlRouterProvider,$ocLazyLoadProvider,myModulesConfig) {
    $ocLazyLoadProvider.config({
        debug:false,
        events:false,
        modules:myModulesConfig
    });
    $urlRouterProvider.when("", "/welcome");
    $stateProvider
        .state("welcome", {
            url:"/welcome",
            templateUrl: "template/welcome.html",
            resolve:loadSequence("ngDialog","welcome"),
            controller:"welcome"
        })
        .state("userManager", {
            url:"/userManager",
            templateUrl: "template/userManager.html",
            resolve:loadSequence("ngDialog","table","userManager"),
            controller:"userManager"
        })
        .state("roleManager", {
            url:"/roleManager",
            templateUrl: "template/roleManager.html",
            resolve:loadSequence("ngDialog","table","roleManager"),
            controller:"roleManager"
        })
        .state("account",{
            url:"/account",
            templateUrl: "template/account.html",
            resolve:loadSequence("ngDialog","table","account"),
            controller:"account"
        })
        .state("domainDetection",{
            url:"/domainDetection",
            templateUrl: "template/domainDetection.html",
            resolve:loadSequence("ngDialog","table","datatype","xlsx","domainDetection"),
            controller:"domainDetection"
        })
        .state("domainManager",{
            url:"/domainManager",
            templateUrl: "template/domainManager.html",
            resolve:loadSequence("ngDialog","table","datePicker","datatype","xlsx","domainManager"),
            controller:"domainManager"
        })
        .state("certificateManager",{
            url:"/certificateManager",
            templateUrl: "template/certificateManager.html",
            resolve:loadSequence("ngDialog","table","datePicker","datatype","xlsx","certificateManager"),
            controller:"certificateManager"
        })
        .state("certificateBillManager",{
            url:"/certificateBillManager",
            templateUrl: "template/certificateBillManager.html",
            resolve:loadSequence("ngDialog","table","echarts","datePicker","certificateBillManager"),
            controller:"certificateBillManager"
        })
        .state("detailsManager",{
            url:"/detailsManager",
            templateUrl: "template/detailsManager.html",
            resolve:loadSequence("ngDialog","table","echarts","datePicker","detailsManager"),
            controller:"detailsManager"
        })
        .state("detailsManagerDetail",{
            url:"/detailsManagerDetail/:domain",
            templateUrl: "template/detailsManager.html",
            resolve:loadSequence("ngDialog","table","echarts","datePicker","detailsManager"),
            controller:"detailsManager"
        })
        .state("domainBillManager",{
            url:"/domainBillManager",
            templateUrl: "template/domainBillManager.html",
            resolve:loadSequence("ngDialog","table","imgUpload","domainBillManager"),
            controller:"domainBillManager"
        })
        .state("serviceManager",{
            url:"/serviceManager",
            templateUrl: "template/serviceManager.html",
            resolve:loadSequence("ngDialog","table","datePicker","datatype","xlsx","serviceManager"),
            controller:"serviceManager"
        })
        .state("serviceBillManager",{
            url:"/serviceBillManager",
            templateUrl: "template/serviceBillManager.html",
            resolve:loadSequence("ngDialog","table","imgUpload","serviceBillManager"),
            controller:"serviceBillManager"
        })
        .state("cheakMonitoring",{
            url:"/cheakMonitoring",
            templateUrl: "template/cheakMonitoring.html",
            resolve:loadSequence("ngDialog","table","cheakMonitoring"),
            controller:"cheakMonitoring"
        })
        .state("operatingRecord",{
            url:"/operatingRecord",
            templateUrl: "template/operatingRecord.html",
            resolve:loadSequence("ngDialog","table","operatingRecord"),
            controller:"operatingRecord"
        });


    function loadSequence() {
        var _args = arguments;
        return {
            deps: ['$ocLazyLoad', '$q','$rootScope',
                function ($ocLL, $q, rs) {
                    var promise = $q.when(1);
                    for (var i = 0, len = _args.length; i < len; i++) {
                        promise = promiseThen(_args[i])
                    }
                    promise.then(function () {
                        if(["welcome","account"].indexOf(_args[_args.length-1])<0)
                            rs.nowMenu =rs.menuInfo.filter(function (n) {
                                return n.memo==_args[_args.length-1];
                            })[0];
                        else{
                            rs.nowMenu={memo:_args[_args.length-1]}
                        }
                    });
                    return promise;

                    function promiseThen(name) {
                        return promise.then(function () {
                            return $ocLL.load(name);
                        });
                    }
                }]
        };
        
    }
    
}])
    .directive("nav",function() {
        return {
            restrict: "AE",
            template :'<div class="nav">\
                    <ul ng-if="finish>0">\
                        <li class="nav-first" ng-class="{true:\'nav-active\'}[nowMenu.memo==\'welcome\']"  ><a class="waves-effect waves-dark" ui-sref="welcome">首页</a></li>\
                        <li class="nav-first" ng-repeat="menu in menuTree" ng-class="{true:\'nav-open\'}[nowMenu.parentId==menu.id]" ><i class="icon-xiangxia1"></i><a ng-bind="menu.name"></a>\
                            <ul class="nav-second" ng-style="{true:{\'display\':\'block\'}}[nowMenu.parentId==menu.id]">\
                                <li ng-repeat="smenu in menu.child" ng-class="{true:\'nav-active\'}[nowMenu.memo==smenu.memo]" >\
                                    <a class="waves-effect waves-dark" href="#!/{{smenu.memo}}" ng-bind="smenu.name"></a>\
                                </li>\
                            </ul>\
                        </li>\
                    </ul>\
                    </div>',
            link: function (scope, element, attrs, ctrl) {
                $(element).on('click','a',function(){
                    if(!$(this).attr("href")){
                        if($(this).parent("li").hasClass("nav-open")){
                            $(this).parent("li").removeClass("nav-open");
                            $(this).next(".nav-second").slideUp();
                        }else{
                            $(this).parent("li").addClass("nav-open");
                            $(this).next(".nav-second").slideDown();
                        }
                    }
                })
            }
        }
    })
    .directive("navActive",function() {
        return {
            replace:true,
            restrict: "AE",
            template: '<div class="navActive open waves-effect waves-dark"><i class="icon-xiangzuo1"></i><i class="icon-xiangyou1"></i></div>',
            link: function (scope, element, attrs, ctrl) {
                $(element).click(function () {
                    if($(this).hasClass("open")){
                        $(".nav").css("left","-200px");
                        $(".view").css("left","0");
                        $(this).removeClass("open");
                        $(this).addClass("close");
                        scope.$broadcast("openNav");
                        scope.$emit("openNav");
                    }else{
                        $(".nav").css("left","0");
                        $(".view").css("left","200px");
                        $(this).removeClass("close");
                        $(this).addClass("open");
                        scope.$broadcast("closeNav");
                        scope.$emit("closeNav");
                    }
                })
            }
        }
    });