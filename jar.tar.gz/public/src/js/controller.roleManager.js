(function() {
    app.controller('addRole',['$scope', 'http','$rootScope', function (s, http,rs) {
        s.role={
            menuIds:[]
        };
        s.menuInfo=[];
        http.post("findPlatform.do",{},function (res) {
            if(res.status==100000) {
                s.platform=res.message;
            }
        })
        for(var i=0;i<rs.menuInfo.length;i++){
            if(rs.userInfo.actIds.indexOf(rs.menuInfo[i].id)>-1){
                s.menuInfo.push(angular.copy(rs.menuInfo[i]));
            }
        }
        if(s.ngDialogData){
            s.role.id=s.ngDialogData.id;
            s.role.name=s.ngDialogData.name;
            s.role.memo=s.ngDialogData.memo;
            s.role.departmentCode=''+s.ngDialogData.departmentCode;
            s.role.departmentName=s.ngDialogData.departmentName;
            s.role.menuIds=s.ngDialogData.menuIds;
            for(var i=0;i<s.menuInfo.length;i++){
                if(s.role.menuIds.indexOf(s.menuInfo[i].id)>-1){
                    s.menuInfo[i].checked=true;
                }
            }
        }
        s.changeDepartment=function () {
            s.role.departmentName=s.platform.filter(function (n) {
               return n.id==s.role.departmentCode
            })[0].name;
        };
        s.check=function(){
            if(!s.role.name){
                s.error=true;
                s.errorMsg="请填写角色名！";
                return false;
            }
            if(s.role.name && !/^[a-zA-Z0-9\u4e00-\u9fa5]+$/.test(s.role.name)){
                s.error=true;
                s.errorMsg="角色名仅能使用汉字、数字与字母组成！";
                return false;
            }
            if(!s.role.departmentCode){
                s.error=true;
                s.errorMsg="请选择所属部门！";
                return false;
            }
            s.role.menuIds=[];
            for(var i=0;i<s.menuInfo.length;i++){
                if(s.role.menuIds.indexOf(s.menuInfo[i].id)<0 && s.menuInfo[i].checked){
                    s.role.menuIds.push(s.menuInfo[i].id);
                }
            }
            if(s.role.menuIds.length==0){
                s.error=true;
                s.errorMsg="请勾选权限！";
                return false;
            }
            return true
        };
        s.sub=function () {
            if(!s.loading && s.check()){
                s.loading=true;
                http.post("saveRole.do",s.role,function (res) {
                    s.loading=false;
                    if(res.status==100000){
                        s.closeThisDialog(res)
                    }else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }

        }
    }]);

    app.controller('roleManager', ['$scope', '$rootScope','Table','ngDialog','http','Tip',function (s, rs, Table,ngDialog,http,tip) {
        s.table =Table.init({link: "queryRoles.do"});
        s.table.getList();

        s.delRole=function(role){
            ngDialog.open({
                template:'<div class="confirm-dialog"> \
            <h2>您确定要删除角色“'+role.name+'”吗？</h2>\
            <div align="center">\
                <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
            </div></div>',
                plain: true
            }).closePromise.then(function (data) {
                if (data.value && data.value=='CONFIRM') {
                    http.post("delRole.do",{roleId:role.id},function (res) {
                        if(res.status==100000){
                            s.table.getList(1);
                            tip.success("删除成功！")
                        }else if(res.status== 100050){
                            tip.error("角色已关联用户，无法删除！")
                        }
                    })
                }
            });
        };
        s.editRole=function (role) {
            ngDialog.open({
                template:"template/roleDialog.html",
                controller:"addRole",
                data:role,
                className:"ngdialog-theme-default large"
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    s.refreshRole();
                    tip.success("修改成功！");
                }
            });
        };
        s.addRole=function () {
            ngDialog.open({
                template:"template/roleDialog.html",
                controller:"addRole",
                className:"ngdialog-theme-default large"
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    s.refreshRole();
                    tip.success("添加成功！");
                }
            });
        };
        s.refreshRole=function () {
            http.post("getAllRoles.do",{},function (res) {
                if(res.status==100000){
                    rs.roleInfo=res.message;
                    store.set("roleInfo",res.message);
                    rs.roleList={};
                    for(var i=0;i<rs.roleInfo.length;i++){
                        rs.roleList[rs.roleInfo[i].id]=rs.roleInfo[i].name;
                    }
                }else{
                    location.href="login.html";
                }
            });
        }
    }]);
})();
