(function() {
    app.controller('serviceDetail',['$scope','http','$filter', function (s,http,$filter) {
        s.service=angular.copy(s.ngDialogData);
        if(!s.service.id){
            if(s.service.serviceIp){
                s.service.status=''+s.service.status;
                s.service.buyStartDate=$filter("date")(s.service.buyStartDate,"yyyy-MM-dd HH:mm:ss");
                s.service.priceType=s.service.price.split("/")[0];
                s.service.perPrice=s.service.price.split("/")[1];
                s.service.perMonth=s.service.price.split("/")[2];
                s.service.buyEndDate=$filter("date")(s.service.buyEndDate,"yyyy-MM-dd HH:mm:ss");
            }
            else{
                s.service.status='2';
                s.service.type="独立服务器";
                s.service.priceType="￥";
                s.service.perPrice="";
                s.service.perMonth="1月";
            }
            s.api="saveServiceIp.do"
        }else{
            s.service.status=''+s.service.status;
            s.service.buyStartDate=$filter("date")(s.service.buyStartDate,"yyyy-MM-dd HH:mm:ss");
            s.service.priceType=s.service.price.split("/")[0];
            s.service.perPrice=s.service.price.split("/")[1];
            s.service.perMonth=s.service.price.split("/")[2];
            s.service.buyEndDate=$filter("date")(s.service.buyEndDate,"yyyy-MM-dd HH:mm:ss");
            s.api="updateServiceIp.do"
        }

        s.check=function () {
            if(!s.service.serviceIp){
                s.error=true;
                s.errorMsg="请输入服务器IP";
                return false
            }
            if(!s.service.allocation){
                s.error=true;
                s.errorMsg="请输入服务器配置";
                return false
            }
            if(!s.service.status){
                s.error=true;
                s.errorMsg="请输入服务器状态";
                return false
            }
            if(!s.service.area){
                s.error=true;
                s.errorMsg="请输入服务器地区";
                return false
            }
            if(!s.service.perPrice){
                s.error=true;
                s.errorMsg="请输入服务器价格";
                return false
            }
            if(!s.service.supplierContact){
                s.error=true;
                s.errorMsg="请输入供应商联系方式";
                return false
            }
            if(!s.service.buyStartDate){
                s.error=true;
                s.errorMsg="请输入服务器购买时间";
                return false
            }
            if(!s.service.bankCard){
                s.error=true;
                s.errorMsg="请输入银行卡号";
                return false
            }
            if(!s.service.bankUsername){
                s.error=true;
                s.errorMsg="请输入银行持卡人";
                return false
            }
            if(!s.service.bankName){
                s.error=true;
                s.errorMsg="请输入开户银行";
                return false
            }
            if(!s.service.platform){
                s.error=true;
                s.errorMsg="请输入平台";
                return false
            }
            s.service.price=s.service.priceType+"/"+s.service.perPrice+"/"+s.service.perMonth;
            return true;
        };
        s.sub=function () {
            if(s.check())
                http.post(s.api,s.service,function (res) {
                    if(res.status==100000){
                        s.closeThisDialog(res);
                    }else if(res.status==100050){
                        s.error=true;
                        s.errorMsg="服务器已存在";
                    }
                    else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
        }
    }]);
    app.controller('serviceManager', ['$scope','$rootScope','$stateParams', 'Table','ngDialog','http','Tip', function (s,rs,$stateParams,Table,ngDialog,http,tip) {
        s.checkValue=[];
        s.now = + new Date();
        s.table =Table.init({link: "queryServiceIp.do"});
        s.table.getList();
        s.xlsOption={
            startRow:2,
            col:["A","B","C","D","E",
                "F","G","H","I","J",
                "K","L","M","N","O","P","Q","R"],
            colName:["serviceIp","allocation","area","type","platform","price",
                "supplierContact","buyStartDate","buyEndDate","function","vpsUrl","vpsUsername",
                "vpsPassword","vpsEmail","vpsMobile","bankCard","bankUsername","bankName"]
        };
        s.$on("xlsxReady",function (event,data) {
            http.post("loadServiceIp.do",{param:data},function (res) {
                if(res.status==100000){
                    s.$broadcast("clearXlsx");
                    tip.success("成功上传"+res.message.SUCCESS+'条，失败'+res.message.FALSE+'条');
                    s.table.getList(1);
                }else if(res.status==100050){
                    tip.error("文件格式错误");
                }else{
                    tip.error(res.message);
                }
            })
        });
        s.$on("readError",function () {
            tip.error("请上传正确格式的文件，支持 xlsx 和 xls 格式");
        });
        s.detail=function (service,status) {
            status?service.id="":"";
            ngDialog.open({
                template:"template/serviceDialog.html",
                controller:"serviceDetail",
                closeByDocument :false,
                data:service,
                className:"ngdialog-theme-default"
            }).closePromise.then(function(data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    var msg = service.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                }
            });
        };
        s.extend=function (list) {
            ngDialog.open({
                template:
                '<div class="confirm-dialog"> \
                <h2>确定延长“'+list.serviceIp+'”的过期时间吗？</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                plain: true
            })
                .closePromise.then(function(data) {
                if (data.value && data.value == "CONFIRM") {
                    http.post("extendService.do", {id:list.id}, function(res) {
                        if (res.status == 100000) {
                            s.table.getList(1);
                            tip.success("延期成功！");
                        }
                    });
                }
            });
        };

        s.export=function () {
            var $iframe = $('<iframe id="down-file-iframe" />');
            var $form = $('<form target="down-file-iframe" method="post" />');
            $form.attr("action", "exportServiceIp.do");
            for (var key in s.table.query) {
                $form.append('<input type="hidden" name="' + key + '" value="' + s.table.query[key] + '" />');
            }
            $iframe.append($form);
            $(document.body).append($iframe);
            $form[0].submit();
            $iframe.remove();
        };

        s.delete= function(service){
            if(service || s.checkValue.length>0){
                var msg="",postData={};
                if(service){
                    msg='您确定要删除服务器“'+service.serviceIp+'”吗？';
                    postData.ids=service.id;
                }else{
                    msg='您确定要删除这些服务器吗？';
                    postData.ids=s.checkValue.join(",");
                }

                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>'+msg+'</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                    .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("deleteServiceIp.do", postData, function(res) {
                            if (res.status == 100000) {
                                s.table.getList(1);
                                tip.success("删除成功！");
                            }
                        });
                    }
                });
            }

        }
    }]);
})();
