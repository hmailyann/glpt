(function() {
    app.controller("changePassword",['$scope','$rootScope', 'http','Tip', function (scope,rs, http,tip) {
        scope.change={
            id:rs.userInfo.id,
            oldPassword:'',
            newPassword:'',
            newPasswordConfirm:''
        };
        scope.check=function () {
            if(!scope.change.oldPassword){
                scope.error=true;
                scope.errorMsg="请输入原密码";
                return false
            }
            if(!scope.change.newPassword){
                scope.error=true;
                scope.errorMsg="请输入新密码";
                return false
            }
            if(!scope.change.newPasswordConfirm){
                scope.error=true;
                scope.errorMsg="请再次输入新密码";
                return false
            }
            if(scope.change.newPassword!=scope.change.newPasswordConfirm){
                scope.error=true;
                scope.errorMsg="两次输入的新密码不一致，请确认后重新输入";
                return false
            }
            return true
        };
        scope.sub=function () {
            if(!scope.loading && scope.check()){
                scope.loading=true;
                http.post("updatePassword.do",{id:scope.change.id,oldPassword:md5(scope.change.oldPassword),newPassword:md5(scope.change.newPassword)},function (res) {
                    scope.loading=false;
                    if(res.status==100000){
                        scope.closeThisDialog();
                        tip.success("修改密码成功！")
                    }else if(res.status==100050){
                        scope.error=true;
                        scope.errorMsg="原密码错误";
                    }else{
                        scope.error=true;
                        scope.errorMsg=res.message;
                    }
                })
            }
        }

    }]);
    app.controller('account', ['$scope', '$rootScope', 'ngDialog', function (s, rs, ngDialog) {
        s.changePassword=function () {
            ngDialog.open({
                template:"template/changePasswordDialog.html",
                controller:"changePassword",
                closeByDocument:false,
                closeByEscape:false,
                showClose:false
            })
        };
        if(rs.userInfo && !rs.userInfo.lastestLoginTime){
            s.changePassword();
        }
    }])
})();

