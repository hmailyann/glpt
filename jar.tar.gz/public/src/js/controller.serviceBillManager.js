(function() {
    app.controller('serviceBillDetail',['$scope','http','$filter', function (s,http,$filter) {
        s.service=angular.copy(s.ngDialogData);
        if(s.service.serviceIp){
            http.post("queryServiceIp.do",{pageNo: 1,
                pageSize: "50",serviceIp:s.service.serviceIp},function (res) {
                if(res.status==100000){
                    for (var index = 0; index < res.message.data.length; index++) {
                        if(s.service.serviceIp==res.message.data[index].serviceIp)
                        {
                            s.service = res.message.data[index];
                        }
                    }
                    s.service.status=''+s.service.status;
                    s.service.buyStartDate=$filter("date")(s.service.buyStartDate,"yyyy-MM-dd HH:mm:ss");
                    s.service.priceType=s.service.price.split("/")[0];
                    s.service.perPrice=s.service.price.split("/")[1];
                    s.service.perMonth=s.service.price.split("/")[2];
                    s.service.buyEndDate=$filter("date")(s.service.buyEndDate,"yyyy-MM-dd HH:mm:ss");
                }else{
                    s.error=true;
                    s.errorMsg=res.message;
                }
            })
        }
    }]);
    app.controller('changeServiceRemark',['$scope','http',function (s,http) {
        s.list=angular.copy(s.ngDialogData);
        s.sub=function () {
            var postData={
                id:s.list.id,
                remark:s.list.remark
            };
            if(s.list.imgUrl!=s.ngDialogData.imgUrl){
                postData.imgUrl=s.list.imgUrl;
            }
            http.post("saveBillServiceRemark.do",postData,function (res) {
                if(res.status==100000){
                    s.closeThisDialog(res);
                }else{
                    s.error=true;
                    s.errorMsg=res.message;
                }
            })
        }
    }])
    app.controller("confirmServiceBill",['$scope','http','$filter',function (s,http,$filter) {
        http.post("applyServiceBill.do",{date:$filter("date")(s.ngDialogData.keyDate,"yyyy-MM-dd"),platform:s.ngDialogData.platform},function (res) {
            if(res.status==100000){
                s.billList=res.message;
                for(var i=0;i<s.billList.serviceBill.length;i++){
                    s.billList.serviceBill[i].checked=true;
                    if(s.billList.serviceBill[i].isPostpone || s.billList.serviceBill[i].remainTime<=0){
                        s.billList.serviceBill[i].checked=false
                    }
                }
            }
        })
        s.sub=function () {
            var ids=[];
            for(var i=0;i<s.billList.serviceBill.length;i++){
                if(s.billList.serviceBill[i].checked){
                    ids.push(s.billList.serviceBill[i].id)
                }
            }
            if(ids.length==0){
                s.error=true;
                s.errorMsg="请勾选需要确认续费的服务器";
            }else {
                http.post("extendService.do", {ids: ids.join(",")}, function (res) {
                    if (res.status == 100000) {
                        s.closeThisDialog(res)
                    } else {
                        s.error = true;
                        s.errorMsg = res.message;
                    }
                })
            }
        }
    }])
    app.controller('serviceBillManager', ['$scope','Table','http','ngDialog','Tip', function (s,Table,http,ngDialog,tip) {
        s.mergeRow=[];
        s.rowspan={};
        s.$on("repeatFinish",function () {
            setTimeout(function () {
                s.mergeRow.push(s.table.list.length);
                for(var i=0;i<s.mergeRow.length;i++){
                    if(s.mergeRow[i+1]){
                        s.rowspan[s.mergeRow[i]]=s.mergeRow[i+1]-s.mergeRow[i]
                    }
                }
                s.$apply();
            })
        });
        s.bClass=function(r,a){
            if(a) {
                if(a==1) {
                    if(s.table.list[r].status=!0){
                        return true
                    }
                }
                else{
                    for (var index = r; index < (r + a); index++) {
                        if(s.table.list[index].status=!0){
                            return true
                        }                    
                    }
                }
            }
            return false
        };

        s.table =Table.init({link: "queryServiceBill.do"});

        s.table.getList();
        
        s.printTable=function (list,r,a) {
            var isOkay = false;
                if(a==1) {
                    if(s.table.list[r].status!='0'){
                        console.log(2)
                        isOkay = true
                    }
                }
                else{
                    for (var index = r; index < (r + a); index++) {
                        if(s.table.list[index].status=!0){
                            console.log(3)

                        isOkay = true
                        }                    
                    }
                }
                console.log(isOkay)
                if(isOkay){
                    window.open("serviceBillPage.html?date=" + list.keyDate +"&platform="+encodeURIComponent(list.platform), "",
                    "height=800, width=800, top=80, left=600, toolbar=no, menubar=no,location=no, status=no")
                }
                else{
                    tip.success('没有可用账单');

                }

           
        }
        s.detail=function (service,status) {
            status?service.id="":"";
            ngDialog.open({
                template:"template/serviceBillDialog.html",
                controller:"serviceBillDetail",
                closeByDocument :false,
                data:service,
                className:"ngdialog-theme-default"
            }).closePromise.then(function(data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    var msg = service.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                }
            });
        };
        s.changeRemark=function (list) {
            ngDialog.open({
                template:"template/billRemarkDialog.html",
                controller:"changeServiceRemark",
                data:list
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    tip.success("修改成功!");
                    s.table.getList();
                }
            });
        }
        s.confirmBill=function (list) {
            ngDialog.open({
                template:"template/billConfirmDialog.html",
                controller:"confirmServiceBill",
                data:list
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    tip.success("操作成功!");
                    s.table.getList();
                }
            });
        }
    }]);
})();
