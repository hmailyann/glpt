app.directive("xlsx",function() {
    return {
        restrict: "AE",
        link: function (scope, element, attrs, ctrl) {
            var xlsxArr=[],xlsxOption;
            if(attrs.xlsx){
                xlsxOption=scope.$eval(attrs.xlsx);
            }else{
                xlsxOption={
                    startRow:1,
                    col:['A','B','C'],
                    colName:['A','B','C']
                }
            }
            element.on("change",function (event) {
                xlsxArr=[];
                if(event.target.files.length>0){
                    var file = event.target.files[0];
                    var reader = new FileReader();
                    var error=false;
                    reader.onload = function(e) {
                        try{
                            var data = e.target.result;
                            var workbook= XLSX.read(data, {type: 'binary'});
                            var sheet_name_list = workbook.SheetNames;
                            sheet_name_list.forEach(function(y) {
                                var worksheet = workbook.Sheets[y];
                                if(worksheet['!ref']){
                                    var rowNo=parseInt(worksheet['!ref'].split(':')[1].match(/\d+$/gi)[0])-xlsxOption.startRow+1;
                                    for(var i=0;i<rowNo;i++){
                                        xlsxArr.push({});
                                    }
                                    for (var z in worksheet) {
                                        if(z.indexOf("!")<0){
                                            var row=parseInt(z.match(/\d+$/gi)[0]);
                                            var col=z.match(/^[A-Z]+/gi)[0];
                                            var colName=xlsxOption.colName[xlsxOption.col.indexOf(col)];
                                            if(row-xlsxOption.startRow>=0 && colName){
                                                worksheet[z].v =String(worksheet[z].v).replace(/<\/?.+?>/g,"");
                                                worksheet[z].v =String(worksheet[z].v).replace(/[\r\n]/g, "");
                                                worksheet[z].v =String(worksheet[z].v).replace(/(^\s*)|(\s*$)/g, "");
                                                xlsxArr[row-xlsxOption.startRow][colName]=worksheet[z].v;
                                            }
                                        }
                                    }
                                }
                            });
                            if(!error){
                                xlsxArr=xlsxArr.filter(function (n) {
                                    for(var i in n){
                                        return true
                                    }
                                    return false
                                });
                                scope.$emit('xlsxReady',xlsxArr);
                            }
                        }
                        catch (e){
                            console.error(e);
                            scope.$emit('readError', e);
                        }
                    };
                    reader.readAsBinaryString(file);
                }
            });
            scope.$on("clearXlsx",function () {
                element[0].value = '';
            })
        }
    }
});

