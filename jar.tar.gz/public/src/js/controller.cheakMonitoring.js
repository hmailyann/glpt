(function() {
    app.controller('cheakMonitoringDetail',['$scope','http','$filter', function (s,http,$filter) {
        s.service=angular.copy(s.ngDialogData);
        if(!s.service.id){
            s.api="saveHijackMonitoring.do"
        }else{
            s.api="updateHijackMonitoring.do"
        }

        s.check=function () {
            if(!s.service.name){
                s.error=true;
                s.errorMsg="请输入检测点名称";
                return false
            }
            if(!s.service.ip){
                s.error=true;
                s.errorMsg="请输入检测点IP";
                return false
            }
            if(!s.service.province){
                s.error=true;
                s.errorMsg="请输入省份";
                return false
            }
            if(!s.service.operator){
                s.error=true;
                s.errorMsg="请输入运营商";
                return false
            }
            return true;
        };
        s.sub=function () {
            if(s.check())
                http.post(s.api,s.service,function (res) {
                    if(res.status==100000){
                        s.closeThisDialog(res);
                    }else if(res.status==100050){
                        s.error=true;
                        s.errorMsg="监测点已存在";
                    }
                    else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
        }
    }]);

    app.controller('cheakMonitoring', ['$scope','$rootScope','$stateParams', 'Table','ngDialog','http','Tip', function (s,rs,$stateParams,Table,ngDialog,http,tip) {
        s.checkValue=[];
        s.table =Table.init({link: "queryHijackMonitoring.do"});
        s.table.getList();
        s.detail=function (list) {
            ngDialog.open({
                template:"template/cheakMonitoringDialog.html",
                controller:"cheakMonitoringDetail",
                closeByDocument :false,
                data:list,
                className:"ngdialog-theme-default"
            }).closePromise.then(function(data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    var msg = list.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                }
            });
        };

        s.delete= function(list){
            if(list || s.checkValue){
                var msg="",postData={};
                if(list){
                    msg='您确定要删除监测点“'+list.name+'”吗？';
                    postData.ids=list.id;
                }else{
                    msg='您确定要删除这些监测点吗？';
                    postData.ids=s.checkValue.join(",");
                }

                ngDialog.open({
                    template:
                    '<div class="confirm-dialog"> \
                    <h2>'+msg+'</h2>\
                    <div align="center">\
                        <button type="button" class="btn btn-red" ng-click="closeThisDialog(\'CONFIRM\')">确定</button>\
                        <button type="button" class="btn btn-default" ng-click="closeThisDialog()">取消</button>\
                    </div></div>',
                    plain: true
                })
                    .closePromise.then(function(data) {
                    if (data.value && data.value == "CONFIRM") {
                        http.post("deleteHijackMonitoring.do", postData, function(res) {
                            if (res.status == 100000) {
                                s.table.getList(1);
                                tip.success("删除成功！");
                            }
                        });
                    }
                });
            }

        }
    }]);
})();
