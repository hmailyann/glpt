(function() {
    app.factory('Table', ["$http","$rootScope", function ($http,rs) {
        function Table(){
            this.list=[];
            this.query={
                pageNo: 1,
                pageSize: '50'
            }
        }
        Table.prototype.init=function (option) {
            this.error=false;
            this.ready=false;
            this.list=[];
            this.query={
                pageNo: 1,
                pageSize: '50'
            };
            this.link = option.link;
            this.callback=option.callback || function () {};
            if (option.query)
                this.query = angular.extend(this.query, option.query);
            return this;
        };
        Table.prototype.getList=function (page) {
            var me=this;
            var link=this.link;
            me.ready=false;
            page = page || me.query.pageNo;
            me.query.pageNo = page;
            $http({
                url: me.link,
                data: me.query,
                method: 'POST'
            }).then(function (bk) {
                var res = bk.data;
                if(link==me.link){
                    if (res.status == 100000) {
                        me.list = res.message.data;
                        me.totalCount=res.message.totalCount;
                        me.pageCount = res.message.totalPages;
                    }
                    else if(res.status==110002){
                        location.href = "login.html";
                    }
                    else {
                        me.error = true;
                        me.errorMsg = res.message;
                    }
                    me.callback(res);
                    rs.$broadcast("gotList");
                    rs.$emit("gotList");
                }
            }).catch(function (err) {
                me.error = true;
                me.errorMsg = err.status;
            }).finally(function () {
                me.ready = true;
            });
        };
        return new Table();
    }]);
    app.directive("tableFloatHeader",["$compile",function ($compile) {
        return {
            restrict: "AE",
            template: '<div class="table-float-header"></div>',
            link: function (scope, element, attrs, ctrl) {
                var ele=$(element).find(".table-float-header");
                var tbd=$("."+attrs.floatThead).find("td");
                if(attrs.floatElement)
                    ele.html($compile($("."+attrs.floatElement).clone())(scope));
                var thead=$("<table></table>");
                thead.html($compile($("."+attrs.floatThead).clone())(scope));
                $(element).find(".table-float-header").append(thead);
                var thd=thead.find("td");
                function resize() {
                    for(var i=0;i<thd.length;i++){
                        thd.eq(i).width(tbd.eq(i).width());
                    }
                }
                angular.forEach(['gotList','openNav','closeNav'], function(value){
                    scope.$on(value,function () {
                        setTimeout(function () {
                            resize()
                        },500)
                    });
                });
                scope.$on("gotList openNav closeNav",function () {
                    setTimeout(function () {
                        resize()
                    },500)
                });
                $('.view').on('scroll',function(){
                    ele.css("top",$(this).scrollTop()+"px");
                    if ($(this).scrollTop() >70) {
                        ele.show();
                    }else{
                        ele.hide();
                    }
                });
            }
        }
    }])

    app.directive("tableFixedTr",function () {
        return {
            restrict: "AE",
            link: function (scope, element, attrs, ctrl) {
                var fixed=function () {
                    var trLen=$(element).find("tbody tr").length;
                    if(trLen>attrs.tableFixedTr){
                        for(var i=0;i<trLen-attrs.tableFixedTr;i++){
                            $(element).find("tbody tr").eq($(element).find("tbody tr").length-1).remove();
                        }
                    }else if(trLen<attrs.tableFixedTr){
                        for(var j=0;j<attrs.tableFixedTr-trLen;j++){
                            var tr=$("<tr></tr>");
                            tr.append("<td colspan='"+$(element).find("thead tr td").length+"'>&#12288;</td>");
                            $(element).find("tbody").append(tr)
                        }
                    }
                };
                scope.$on("repeatFinish",function (e,data) {
                    setTimeout(function () {
                        if(attrs.eventData){
                            if(attrs.eventData==data)
                                fixed();
                        }else{
                            fixed();
                        }
                    },0)
                })
            }
        }
    });

    app.directive('repeatFinish',function(){
        return {
            restrict: "AE",
            link: function(scope, element, attrs, ctrl){
                if(scope.$last == true){
                    scope.$emit('repeatFinish',attrs.repeatFinish);
                    scope.$broadcast('repeatFinish',attrs.repeatFinish);
                }
            }
        }
    });


    app.directive("tablePage", function () {
        return {
            restrict: "AE",
            template: '<div class="table-page"></div>',
            link: function (scope, element, attrs, ctrl) {
                var tablep;
                scope.$watch(attrs.tablePage, function (table) {
                    tablep=table;
                    if (table && table.pageCount && table.pageCount > 1) {
                        $(element).find(".table-page").html('<span class="pre">上一页</span>\
                        <span class="next">下一页</span>');
                        if (table.query.pageNo == 1) {
                            $(element).find(".pre").addClass("disabled")
                        } else if (table.query.pageNo == table.pageCount) {
                            $(element).find(".next").addClass("disabled")
                        }
                        var html = "";
                        if (table.pageCount > 10) {
                            if (table.query.pageNo < 6) {
                                for (var i = 1; i <= table.query.pageNo + 2; i++) {
                                    if (i == table.query.pageNo)
                                        html += '<span class="page-to now">' + i + '</span>';
                                    else
                                        html += '<span class="page-to">' + i + '</span>';
                                }

                                html += '...<span class="page-to">' + table.pageCount + '</span>'
                            }
                            else if (table.query.pageNo >= 6 && table.query.pageNo < table.pageCount - 2) {
                                html += '<span class="page-to">1</span>...';
                                for (var i = table.query.pageNo - 2; i <= table.query.pageNo + 2; i++) {
                                    if (i == table.query.pageNo)
                                        html += '<span class="page-to now">' + i + '</span>';
                                    else
                                        html += '<span class="page-to">' + i + '</span>';
                                }
                                html += '...<span class="page-to">' + table.pageCount + '</span>'
                            } else {
                                html += '<span class="page-to">1</span>...';
                                for (var i = table.query.pageNo - 2; i <= table.pageCount; i++) {
                                    if (i == table.query.pageNo)
                                        html += '<span class="page-to now">' + i + '</span>';
                                    else
                                        html += '<span class="page-to">' + i + '</span>';
                                }
                            }
                        } else {
                            for (var i = 1; i <= table.pageCount; i++) {
                                if (i == table.query.pageNo)
                                    html += '<span class="page-to now">' + i + '</span>';
                                else
                                    html += '<span class="page-to">' + i + '</span>';
                            }
                        }
                        $(element).find(".pre").after(html);
                    }else{
                        $(element).find(".table-page").html("");
                    }
                }, true);

                $(element).on('click', '.page-to', function () {
                    if (!$(this).hasClass("now")) {
                        tablep.getList(parseInt($(this).text()));
                    }
                });
                $(element).on('click', '.pre', function () {
                    if (!$(this).hasClass("disabled")) {
                        tablep.getList(tablep.query.pageNo - 1);
                    }
                });
                $(element).on('click', '.next', function () {
                    if (!$(this).hasClass("disabled")) {
                        tablep.getList(tablep.query.pageNo + 1);
                    }
                });
            }
        }
    })
})()