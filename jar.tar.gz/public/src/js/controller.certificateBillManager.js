(function () {
    app.controller('certBillDetail',['$scope','http','$filter', function (s,http,$filter) {
        s.domainUrl=angular.copy(s.ngDialogData);
        
        if(s.domainUrl.certName){
            http.post("queryCertificateByCondition.do",{name:s.domainUrl.certName},function (res) {
                if(res.status==100000){

                    for (var index = 0; index < res.message.data.length; index++) {
                        if(s.domainUrl.certName==res.message.data[index].name)
                        {
                            s.domain = res.message.data[index];
                        }
                    }
                    http.post("queryCertEffect.do",{},function (res) {
                        if(res.status=100000){
                            s.certEffectList=res.message;
                            if(!s.domain.id && s.certEffectList.length>0){
                                s.domain.certEffect=s.certEffectList[0].name;
                            }else if(!s.domain.id && s.certEffectList.length==0){
                                s.domain.certEffect="";
                            }
                        }
                    });
                    s.domain.status=''+s.domain.status;
                    s.domain.buyStartDate=$filter("date")(s.domain.buyStartDate,"yyyy-MM-dd HH:mm:ss");
                    s.domain.buyEndDate=$filter("date")(s.domain.buyEndDate,"yyyy-MM-dd HH:mm:ss");
                    s.domain.priceType=s.domain.certPrice.split("/")[0];
                    s.domain.perPrice=s.domain.certPrice.split("/")[1];
                    s.domain.perMonth=s.domain.certPrice.split("/")[2];
                }else{
                    s.error=true;
                    s.errorMsg=res.message;
                }
            })
        }
    

    }]);
    app.controller('changeCertRemark', ['$scope', 'http', function (s, http) {
        s.list = angular.copy(s.ngDialogData);
        s.sub = function () {
            var postData = {
                id: s.list.id,
                remark: s.list.remark
            };
            if (s.list.imgUrl != s.ngDialogData.imgUrl) {
                postData.imgUrl = s.list.imgUrl;
            }
            http.post("saveCertBillRemark.do", postData, function (res) {
                if (res.status == 100000) {
                    s.closeThisDialog(res);
                } else {
                    s.error = true;
                    s.errorMsg = res.message;
                }
            })
        }
    }])
    app.controller("confirmCertBill", ['$scope', 'http', '$filter', function (s, http, $filter) {
        s.billList = {};
        s.billList.certBill=[];
        s.billList.certBill.push(angular.copy(s.ngDialogData))
        for (var i = 0; i < s.billList.certBill.length; i++) {
            s.billList.certBill[i].checked = true;
            if (s.billList.certBill[i].isPostpone || s.billList.certBill[i].remainTime <= 0) {
                s.billList.certBill[i].checked = false
            }
        }

        s.sub=function () {
            var ids=[];
            for(var i=0;i<s.billList.certBill.length;i++){
                if(s.billList.certBill[i].checked){
                    ids.push(s.billList.certBill[i].id)
                }
            }
            if(ids.length==0){
                s.error=true;
                s.errorMsg="请勾选需要确认续费的证书";
            }else{
                http.post("certificatePostpone.do",{id:ids[0]},function (res) {
                    if(res.status==100000){
                        s.closeThisDialog(res)
                    }else{
                        s.error=true;
                        s.errorMsg=res.message;
                    }
                })
            }

        }
    }])
    app.controller('certificateBillManager', ['$scope', 'Table', 'http', 'ngDialog', 'Tip', '$filter', function (s, Table, http, ngDialog, tip, $filter) {
        http.post("queryDomainEffect.do", {}, function (res) {
            if (res.status = 100000) {
                s.certEffectList = res.message;
            }
        });
        s.mergeRow = [];
        s.rowspan = {};
        s.table = Table.init({
            link: "queryCertificateBillByCondition.do"
        });
        s.table.getList();
        s.$on("repeatFinish", function () {
            setTimeout(function () {
                s.mergeRow.push(s.table.list.length);
                for (var i = 0; i < s.mergeRow.length; i++) {
                    if (s.mergeRow[i + 1]) {
                        s.rowspan[s.mergeRow[i]] = s.mergeRow[i + 1] - s.mergeRow[i]
                    }
                }
                s.$apply();
            })
        });
        s.detail = function (domain, status) {
            status ? domain.id = "" : "";
            ngDialog.open({
                template: "template/certBillDialog.html",
                controller: "certBillDetail",
                closeByDocument: false,
                data: domain,
                className: "ngdialog-theme-default large"
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    s.table.getList(1);
                    var msg = domain.id ? "修改成功!" : "保存成功!";
                    tip.success(msg);
                }
            });
        };
        s.printTable = function (list) {
            window.open("certBillPage.html?date=" + list.keyDate + "&platform=" + encodeURIComponent(list.platform) + "&id=" + list.id, "",
                "height=800, width=800, top=80, left=600, toolbar=no, menubar=no,location=no, status=no")
        }
        s.changeRemark = function (list) {
            ngDialog.open({
                template: "template/billRemarkDialog.html",
                controller: "changeCertRemark",
                data: list
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    tip.success("修改成功!");
                    s.table.getList();
                }
            });
        }
        s.confirmBill = function (list) {
            ngDialog.open({
                template: "template/billConfirmDialog.html",
                controller: "confirmCertBill",
                data: list
            }).closePromise.then(function (data) {
                if (data.value && data.value.status == 100000) {
                    tip.success("操作成功!");
                    s.table.getList();
                }
            });
        }
    }]);
})();